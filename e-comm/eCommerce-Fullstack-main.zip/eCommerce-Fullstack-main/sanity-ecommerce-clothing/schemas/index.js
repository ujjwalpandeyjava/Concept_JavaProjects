import product from "./product"
// import banner from "./banner"

export const schemaTypes = [product]
