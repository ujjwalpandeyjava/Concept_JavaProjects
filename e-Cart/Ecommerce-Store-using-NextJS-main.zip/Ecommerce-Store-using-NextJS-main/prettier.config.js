module.exports = {
  arrowParens: 'always',
  singleQuote: true,
  tabWidth: 2,
  semi: true,
  tailwindConfig: './tailwind.config.js',
};
