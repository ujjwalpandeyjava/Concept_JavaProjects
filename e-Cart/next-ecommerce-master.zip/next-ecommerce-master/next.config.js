module.exports = {
  pageExtensions: ['js'],
  images: {
    domains: ['m.media-amazon.com'],
  },
};
