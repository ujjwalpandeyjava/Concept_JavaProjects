export default function Checkout() {
  return <p>Checkout</p>;
}
