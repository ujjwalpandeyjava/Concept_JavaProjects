package gettersSetters;

public class Takes {

	private int x;
	private String s;
	private float f;

	public Takes(int x, String s, float f) {
		super();
		this.x = x;
		this.s = s;
		this.f = f;
	}

	public int getX() {
		return x;
	}

	public String getS() {
		return s;
	}

	public float getF() {
		return f;
	}
}
