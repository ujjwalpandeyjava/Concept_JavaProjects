package utility;

public class Constants {

	public static final String CURRENTHOST = "abc.com";
}
