package interfaceShapes.interfaces;

public interface Shapes {
	public void input();
	public void area();
	public void perameters();
	public void filled();
}
