package other;

public class LetsSolve {
	public static void main(String[] args) {

		System.out.println("ujjwal");
	}
}
