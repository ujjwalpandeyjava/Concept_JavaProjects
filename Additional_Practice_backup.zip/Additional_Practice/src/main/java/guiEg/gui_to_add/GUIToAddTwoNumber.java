package guiEg.gui_to_add;

public class GUIToAddTwoNumber {
	public static void main(String[] args) {
		new Add();
	}
}