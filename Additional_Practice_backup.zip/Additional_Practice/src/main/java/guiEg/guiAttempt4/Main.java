package guiEg.guiAttempt4;

class Main {

	public static void main(String as[]) {
		new Gui();
	}
}
