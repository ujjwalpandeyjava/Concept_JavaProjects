package linked;
public class LinkedListExample {

  public static void main(String[] args) {
    new Lists();
  }
}
