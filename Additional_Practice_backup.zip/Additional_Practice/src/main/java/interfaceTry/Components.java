package interfaceTry;

public interface Components {
  public void tyres(String x);

  public void numberOfSeats(int x);

  public void lights();
}
