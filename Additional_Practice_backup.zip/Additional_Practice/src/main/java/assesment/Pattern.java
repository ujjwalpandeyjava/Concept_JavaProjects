package assesment;

public class Pattern {
	public static void main(String[] args) {
		String string = "aabccaadcbaabc";

//	Pattern = “aa”
//	Output: 3
		System.out.println(string);
	}
}
