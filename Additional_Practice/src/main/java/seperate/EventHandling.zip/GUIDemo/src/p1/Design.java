package p1;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class Design implements ActionListener{
	JFrame fr;
	
	JPanel pan;
	JButton btn1,btn2,btn3;
	JLabel lab;
	JTextField tf;
	
	public Design()
	{
		fr = new JFrame("My Document");
		pan = new JPanel();
		btn1= new JButton("Red");
		btn2= new JButton("Green");
		btn3= new JButton("Yellow");
	
		pan.setSize(499, 499);
		fr.add(pan);
		pan.add(btn1);
		pan.add(btn2);
		pan.add(btn3);
		btn1.addActionListener(this);
		btn2.addActionListener(this);
		btn3.addActionListener(this);
		
		fr.setSize(500, 500);
		fr.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String s = e.getActionCommand();
		if(s.equals("Red"))
			pan.setBackground(Color.RED);
		else if(s.equals("Green"))
			pan.setBackground(Color.GREEN);
		else if(s.equals("Yellow"))
			pan.setBackground(Color.YELLOW);
		
		
	}

}
