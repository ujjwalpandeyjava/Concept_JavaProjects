package p2;

import p1.Design;

public class TestDesign {

	public static void main(String[] args) {
		new Design();

	}

}
